// Fill out your copyright notice in the Description page of Project Settings.

#include "Viatorum.h"
#include "HexagonComponent.h"



UHexagonComponent::UHexagonComponent() :
HexType(EHexagonType::HE_Default) {

}

UHexagonComponent::~UHexagonComponent() {
	RemoveMeshInstance();
}

EHexagonType UHexagonComponent::GetHexagonType() {
	return HexType;
}

void UHexagonComponent::SetHexagonType(EHexagonType Type) {
	this->HexType = Type;

	this->RemoveMeshInstance();
	this->InitializeMeshInstance();
}

#if WITH_EDITOR

void UHexagonComponent::PostEditChangeProperty(FPropertyChangedEvent & Event) {
	Super::PostEditChangeProperty(Event);

	this->RemoveMeshInstance();
	this->InitializeMeshInstance();
}

void UHexagonComponent::PostEditComponentMove(bool bFinished) {
	Super::PostEditComponentMove(bFinished);

	this->UpdateMeshInstance();
}

#endif

void UHexagonComponent::OnUpdateTransform(bool bSkipPhysicsMove) {
	Super::OnUpdateTransform(bSkipPhysicsMove);
	this->UpdateMeshInstance();
}

void UHexagonComponent::OnAttachmentChanged() {
	RemoveMeshInstance();
	AHexGrid* Parent = Cast<AHexGrid>(this->GetAttachmentRootActor());
	Owner = Parent;
	InitializeMeshInstance();
}

void UHexagonComponent::InitializeMeshInstance() {
	if (!(ArrayIndex < 0)) return;
	if (Owner == nullptr) return;
	UInstancedStaticMeshComponent* Comp = Owner->GetMeshComponentByHexagonType(HexType);
	if (Comp == nullptr) return;
	ArrayIndex = Comp->AddInstance(GetRelativeTransform());
}

void UHexagonComponent::UpdateMeshInstance() {
	if (ArrayIndex < 0) return;
	if (Owner == nullptr) return;
	UInstancedStaticMeshComponent* Comp = Owner->GetMeshComponentByHexagonType(HexType);
	if (Comp == nullptr) return;
	Comp->UpdateInstanceTransform(ArrayIndex, GetRelativeTransform());
}

void UHexagonComponent::RemoveMeshInstance() {
	if (ArrayIndex < 0) return;
	if (Owner == nullptr) return;
	UInstancedStaticMeshComponent* Comp = Owner->GetMeshComponentByHexagonType(HexType);
	if (Comp == nullptr) return;
	Comp->RemoveInstance(ArrayIndex);
}

float AHexagonComponent::CalculateZ(float x, float y, float z_start, float z_end) {

	FVector Start(x, y, z_start);
	FVector End(x, y, z_end);

	FCollisionQueryParams RV_TraceParams = FCollisionQueryParams(FName(TEXT("RV_Trace")), true, this);

	RV_TraceParams.bTraceComplex = true;
	RV_TraceParams.bTraceAsyncScene = true;
	RV_TraceParams.bReturnPhysicalMaterial = false;

	FHitResult RV_Hit(ForceInit);

	GetWorld()->LineTraceSingle(
		RV_Hit,
		Start,
		End,
		ECC_WorldStatic,
		RV_TraceParams
		);

	if (RV_Hit.bBlockingHit) {
		return RV_Hit.ImpactPoint.Z;
	}
	else {
		return (z_end + z_start) / 2.f;
	}
}
