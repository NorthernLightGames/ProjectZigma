// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Object.h"
#include "HexagonComponent.generated.h"

class AHexGrid;

UENUM()
enum class EHexagonType : uint8 {
	HE_Default UMETA(DisplayName = "Default")
	// Add more later on
};

UCLASS()
class UHexagonComponent : public USceneComponent {
	GENERATED_BODY()
	
protected:

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Hexagon")
		EHexagonType HexType;

public:

	UHexagonComponent();

	~UHexagonComponent();

	EHexagonType GetHexagonType();
	void SetHexagonType(EHexagonType Type);
	void SetOwningGrid(AHexGrid* Owner);

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent & PropertyChangedEvent) override;
	virtual void PostEditComponentMove(bool bFinished) override;
#endif

	virtual void OnAttachmentChanged() override;
	void UpdateMeshInstance();

protected:

	virtual void OnUpdateTransform(bool bSkipPhysicsMove) override;

private:

	void InitializeMeshInstance();
	void RemoveMeshInstance();
	float CalculateZ(float X, float Y, float Z_start, float Z_end);

	AHexGrid* Owner;

	int32 ArrayIndex;
};
